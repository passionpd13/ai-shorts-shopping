---
name: shopping-shorts-pipeline
description: 쇼핑 쇼츠 자동화 파이프라인을 실행합니다. "쇼핑 쇼츠 파이프라인 시작", "오늘 쇼츠 만들어줘", "쇼핑 쇼츠 생산" 등의 요청에 반응합니다.
version: 1.0.0
author: passionpd
---

# 쇼핑 쇼츠 자동화 파이프라인

## When to Use This Skill
사용자가 다음과 같이 요청할 때 이 스킬을 사용하세요:
- "쇼핑 쇼츠 파이프라인을 시작해줘"
- "오늘 쇼츠 만들어줘"
- "쇼핑 쇼츠 생산해줘"
- 매일 09:00 cron 트리거

## Overview
이 파이프라인은 6단계로 구성됩니다. 각 단계를 순서대로 실행하세요.
에러가 발생하면 해당 단계를 1회 재시도하고, 실패하면 사용자에게 보고하세요.

## Pipeline Steps

### Step 1: 상품 스카우트
`shopping-shorts-scout` 스킬을 호출하세요.
결과로 상품 정보(상품명, 카테고리, 키워드, 댓글키워드)를 받습니다.

### Step 2: 대본 작성
`shopping-shorts-writer` 스킬을 호출하세요.
Step 1의 상품 정보를 전달합니다.
결과로 40초 대본 + 검수 점수를 받습니다.

### Step 3: 영상 소싱
`shopping-shorts-sourcer` 스킬을 호출하세요.
Step 2의 검색 키워드를 사용합니다.
결과로 다운로드된 TikTok 영상 경로를 받습니다.

### Step 4: 영상 클리닝
`shopping-shorts-cleaner` 스킬을 호출하세요.
Step 3의 영상 파일을 처리합니다.
결과로 자막/워터마크 제거된 무음 영상을 받습니다.

### Step 5: 영상 제작
`shopping-shorts-producer` 스킬을 호출하세요.
Step 2의 대본 + Step 4의 클린 영상을 사용합니다.
결과로 완성된 쇼츠 MP4 파일을 받습니다.

### Step 6: 배포
`shopping-shorts-distributor` 스킬을 호출하세요.
Step 5의 영상 + Step 2의 메타데이터를 사용합니다.
4개 플랫폼에 배포하고 결과를 보고합니다.

## 진행 보고
각 단계가 완료될 때마다 사용자에게 보고하세요:
```
✓ Step 1 완료: [상품명] 선정
✓ Step 2 완료: 대본 [X]점/10 (Y자)
✓ Step 3 완료: 영상 소싱 ([해상도], [길이]초)
✓ Step 4 완료: 클리닝 완료
✓ Step 5 완료: 렌더링 완료 ([길이]초, [크기]MB)
✓ Step 6 완료: [N]/4 플랫폼 배포 성공
```

## 에러 처리
- 각 단계 실패 시 1회 재시도
- 2회 실패 시 사용자에게 "Step N에서 실패: [에러 메시지]. --from=N으로 재시작 가능" 보고
- Step 1 실패: 카테고리 확장 후 재시도
- Step 2 실패: 상품 변경 후 재시도
- Step 3 실패: 이 상품 스킵, 다음 상품으로

## 성과 분석 모드
"성과 분석해줘", "쇼츠 성과 확인" 요청 시:
`shopping-shorts-distributor` 스킬의 분석 기능을 호출하세요.

## 설정 파일
모든 설정은 `/opt/shopping-shorts/config/settings.json`을 참조하세요.
