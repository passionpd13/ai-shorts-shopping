---
name: shopping-shorts-cleaner
description: 영상에서 자막과 워터마크를 제거하고 음성을 스트립합니다.
version: 1.0.0
author: passionpd
---

# 쇼핑 쇼츠 영상 클리닝

## When to Use This Skill
- "이 영상에서 자막이랑 워터마크 제거해줘"
- 파이프라인 Step 4로 호출될 때

## Instructions

### 1. GhostCut API로 자막+워터마크 제거
n8n Webhook을 통해 GhostCut 비동기 작업을 제출하세요:
```bash
RESULT=$(curl -s -X POST http://localhost:5678/webhook/shopping-shorts/ghostcut-clean \
  -H "Content-Type: application/json" \
  -d '{
    "videoPath": "[소스 영상 경로]",
    "options": {
      "needChineseOcclude": 1,
      "needCrop": 0,
      "music": 2
    }
  }')
echo "$RESULT"
```

응답에서 taskId를 확인하세요.

### 2. 결과 대기 (폴링)
GhostCut은 비동기입니다. 10초 간격으로 상태를 확인하세요:
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/ghostcut-clean \
  -H "Content-Type: application/json" \
  -d '{"action":"check_status","taskId":"[TASK_ID]"}'
```

status가 "completed"가 될 때까지 반복하세요. 최대 5분 대기.
타임아웃 또는 실패 시 → 폴백으로 진행.

### 3. 폴백: GhostCut 실패 시
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/ghostcut-clean \
  -H "Content-Type: application/json" \
  -d '{"videoPath":"[경로]","provider":"pixelbin"}'
```

Pixelbin도 실패하면 원본 영상을 그대로 사용하세요 (자막/워터마크 잔존 가능).

### 4. 음성 제거 (FFmpeg)
클리닝된 영상에서 원본 오디오를 완전히 제거하세요:
```bash
ffmpeg -y -i "[클린영상]" -an -c:v copy "/opt/shopping-shorts/workspace/cleaned/mute_$(date +%s).mp4"
```

-an 옵션으로 오디오 스트림을 제거합니다.
copy 실패 시 재인코딩:
```bash
ffmpeg -y -i "[클린영상]" -an -c:v libx264 -preset fast "/opt/shopping-shorts/workspace/cleaned/mute_$(date +%s).mp4"
```

### 5. 결과 검증
```bash
ffprobe -v quiet -print_format json -show_format -show_streams "[무음영상]"
```
비디오 스트림 존재 + 길이 5초 이상이면 성공.

### 6. 결과 보고
```
클리닝 완료
파일: [무음 영상 경로]
길이: [N]초
방법: [GhostCut / Pixelbin / 원본유지]
```
