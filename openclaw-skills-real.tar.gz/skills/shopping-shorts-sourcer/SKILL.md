---
name: shopping-shorts-sourcer
description: TikTok에서 상품 관련 영상을 검색하고 다운로드합니다.
version: 1.0.0
author: passionpd
---

# 쇼핑 쇼츠 영상 소싱

## When to Use This Skill
- "TikTok에서 [키워드] 영상 찾아줘"
- 파이프라인 Step 3로 호출될 때

## Instructions

### 1. 키워드 순차 검색 (최대 3개)
대본 스킬에서 받은 검색 키워드를 순서대로 시도하세요.

```bash
# 키워드1로 TikTok 검색 + 상위 3개 다운로드
yt-dlp "ytsearch3:tiktok [키워드1] 리뷰" \
  --no-playlist \
  --max-downloads 3 \
  -f "best[height>=720]" \
  -o "/opt/shopping-shorts/workspace/downloads/source_%(id)s.%(ext)s" \
  --no-warnings 2>/dev/null || true
```

첫 번째 키워드로 적합한 영상을 못 찾으면 다음 키워드로 시도하세요.

### 2. 품질 검증
다운로드된 각 영상에 대해 FFprobe로 확인하세요:
```bash
ffprobe -v quiet -print_format json -show_format -show_streams "/opt/shopping-shorts/workspace/downloads/source_XXXX.mp4"
```

합격 기준:
- 해상도: 최소 720p (width 또는 height 중 작은 값 >= 720)
- 길이: 15초 이상, 180초 이하
- 비디오 스트림 존재

### 3. 결과 보고
```
영상 소싱 완료
파일: [파일명]
해상도: [W]x[H]
길이: [N]초
키워드: [사용한 키워드]
```

### 4. 실패 시
모든 키워드로 적합한 영상을 못 찾으면:
"영상 소싱 실패. 이 상품을 스킵합니다." 보고
품질 미달 파일은 삭제하세요:
```bash
rm -f /opt/shopping-shorts/workspace/downloads/source_*.mp4
```
