---
name: shopping-shorts-producer
description: TTS 음성 생성 + Whisper 타임스탬프 + Remotion 렌더링으로 최종 영상을 만듭니다.
version: 1.0.0
author: passionpd
---

# 쇼핑 쇼츠 영상 제작

## When to Use This Skill
- "이 대본으로 영상 만들어줘"
- 파이프라인 Step 5로 호출될 때

## 필요한 입력
- 대본 텍스트 (Step 2에서)
- 무음 클린 영상 경로 (Step 4에서)
- 댓글 키워드
- 상품명

## Instructions

### 1. Supertone TTS 음성 생성
```bash
curl -s -X POST "https://supertone.ai/api/v1/tts" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $SUPERTONE_API_KEY" \
  -d '{
    "text": "[대본 전체 텍스트]",
    "voice": "cheerful",
    "model": "sona-2",
    "speed": 1.05,
    "language": "ko",
    "output_format": "mp3"
  }' \
  --output /opt/shopping-shorts/workspace/tts/tts_$(date +%s).mp3
```

TTS 길이 확인:
```bash
ffprobe -v quiet -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "/opt/shopping-shorts/workspace/tts/tts_*.mp3"
```

40초에서 크게 벗어나면 (45초 이상 또는 30초 미만):
speed를 조절해서 재생성하세요. 새 speed = (실제길이 / 40) * 1.05

### 2. Whisper 타임스탬프 추출
```bash
curl -s -X POST "https://api.openai.com/v1/audio/transcriptions" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -F file=@"/opt/shopping-shorts/workspace/tts/tts_*.mp3" \
  -F model="whisper-1" \
  -F language="ko" \
  -F response_format="verbose_json" \
  -F "timestamp_granularities[]=word" \
  > /opt/shopping-shorts/workspace/tts/timestamps.json
```

결과 JSON에서 words 배열(단어, start, end)을 확인하세요.

### 3. Remotion 입력 준비
timestamps.json의 데이터를 포함한 Remotion 입력 파일을 생성하세요:
```bash
cat > /opt/shopping-shorts/workspace/output/remotion_input.json << 'REMOTION_EOF'
{
  "script": "[대본 텍스트]",
  "commentKeyword": "[키워드]",
  "timestamps": [Whisper words 배열],
  "ttsDuration": [TTS 길이(초)],
  "ttsPath": "[TTS mp3 절대경로]",
  "videoPath": "[클린 영상 절대경로]",
  "productName": "[상품명]",
  "outputWidth": 1080,
  "outputHeight": 1920,
  "fps": 30
}
REMOTION_EOF
```

### 4. Remotion 렌더링
```bash
cd /opt/shopping-shorts/remotion-shopping-shorts && \
npx remotion render ShoppingShorts \
  "/opt/shopping-shorts/workspace/output/shorts_$(date +%s).mp4" \
  --props="/opt/shopping-shorts/workspace/output/remotion_input.json" \
  --codec=h264 \
  --concurrency=2 \
  --log=error
```

실패 시 --concurrency=1로 재시도하세요.

### 5. Remotion 실패 시 FFmpeg 폴백
```bash
ffmpeg -y \
  -stream_loop -1 -i "[클린영상]" \
  -i "[TTS mp3]" \
  -shortest \
  -c:v libx264 -preset fast \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  "/opt/shopping-shorts/workspace/output/shorts_$(date +%s).mp4"
```

### 6. 출력 검증
```bash
ffprobe -v quiet -print_format json -show_format -show_streams "[출력MP4]"
```
- 비디오 스트림 존재
- 길이 20초 이상
- 파일 크기 500KB 이상

### 7. 결과 보고
```
영상 제작 완료
파일: [출력 경로]
길이: [N]초
해상도: [W]x[H]
크기: [N]MB
렌더: [Remotion / FFmpeg 폴백]
```
