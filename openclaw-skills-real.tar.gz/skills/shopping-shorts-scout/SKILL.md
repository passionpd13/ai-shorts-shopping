---
name: shopping-shorts-scout
description: 쿠팡 베스트 상품을 자율적으로 선정합니다. "오늘 상품 찾아줘", "쿠팡 베스트 확인" 등의 요청에 반응합니다.
version: 1.0.0
author: passionpd
---

# 쇼핑 쇼츠 상품 스카우트

## When to Use This Skill
- "쿠팡에서 오늘 상품 찾아줘"
- "쇼핑 쇼츠용 상품 선정해줘"
- 파이프라인 Step 1로 호출될 때

## 설정
- n8n URL: 설정 파일 `/opt/shopping-shorts/config/settings.json`의 `n8n.base_url` 참조
- 카테고리 목록: 뷰티(1010), 주방(1013), 생활(1014), 건강(1024), 가전(1019), 패션(1020)

## Instructions

### 1. 과거 성과 데이터 확인
먼저 이전에 어떤 카테고리가 잘 됐는지 확인하세요:
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/sheets-record \
  -H "Content-Type: application/json" \
  -d '{"action":"read_performance","days":30}'
```
응답에서 카테고리별 조회수/댓글수/클릭수를 분석하여, 전환율이 높은 카테고리 3개를 선택하세요.
데이터가 없으면(첫 실행) 기본 순서: 생활 → 주방 → 뷰티를 사용하세요.

### 2. 쿠팡 베스트 상품 조회
선택한 카테고리로 쿠팡 베스트를 조회하세요:
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/coupang-search \
  -H "Content-Type: application/json" \
  -d '{"action":"best_products","categoryId":"1014","limit":10}'
```
각 카테고리에서 10개씩 가져옵니다.

### 3. 이미 만든 상품 제외
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/sheets-record \
  -H "Content-Type: application/json" \
  -d '{"action":"read_product_ids"}'
```
응답의 productIds와 겹치는 상품을 제외하세요.

### 4. 최적 상품 선택 (자율 판단)
남은 후보 중에서 아래 기준으로 1개를 선택하세요:
1. **시각적 차이가 명확한 상품** — 사용 전/후가 뚜렷해야 대본이 강력합니다
2. **1만원~5만원 가격대** — 충동구매 가능 범위
3. **리뷰 많은 상품** — 검증된 제품
4. **TikTok 관련 영상이 있을 법한 상품** — 영상 소싱이 쉬워야 함

### 5. 결과 출력
선택한 상품 정보를 다음 형식으로 보고하세요:
```
상품: [상품명]
카테고리: [카테고리명]
가격대: [X만원대]
선정 이유: [1~2문장]
검색 키워드: [키워드1, 키워드2, 키워드3]
댓글 키워드: [1~2글자 일상 단어]
```

댓글 키워드 예시: 청소기→"청소", 이어폰→"음악", 텀블러→"커피", 비타민→"건강", 조명→"분위기"

### 6. 새 상품이 없는 경우
모든 카테고리에서 새 상품이 없으면:
- 나머지 카테고리도 모두 조회
- 그래도 없으면 "오늘은 새 상품이 없습니다. 스킵합니다." 보고
