---
name: shopping-shorts-distributor
description: 4개 플랫폼에 배포하고, 성과를 분석합니다.
version: 1.0.0
author: passionpd
---

# 쇼핑 쇼츠 배포 + 성과 분석

## When to Use This Skill
- "이 쇼츠를 4개 플랫폼에 올려줘"
- "오늘 쇼츠 성과 분석해줘"
- 파이프라인 Step 6로 호출될 때 (배포 모드)
- 매일 22:00 트리거 (분석 모드)

## 배포 모드

### 1. YouTube Shorts 업로드
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/deploy-youtube \
  -H "Content-Type: application/json" \
  -d '{
    "videoPath": "[영상 경로]",
    "title": "[제목]",
    "description": "[설명]\n\n이 포스팅은 쿠팡 파트너스 활동의 일환으로 일정액의 수수료를 제공받습니다.",
    "tags": ["키워드1","키워드2","키워드3"],
    "categoryId": "22",
    "privacyStatus": "public",
    "shorts": true
  }'
```

### 2. Instagram Reels 업로드
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/deploy-instagram \
  -H "Content-Type: application/json" \
  -d '{
    "videoPath": "[영상 경로]",
    "title": "[제목]",
    "caption": "[캡션]\n\n#쇼핑 #추천 #리뷰\n\n이 포스팅은 쿠팡 파트너스 활동의 일환으로 일정액의 수수료를 제공받습니다.",
    "mediaType": "REELS",
    "shareToFeed": true
  }'
```

### 3. TikTok 업로드
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/deploy-tiktok \
  -H "Content-Type: application/json" \
  -d '{
    "videoPath": "[영상 경로]",
    "caption": "[제목]",
    "privacyLevel": "SELF_ONLY",
    "disableComment": false
  }'
```

### 4. Facebook Reels 업로드
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/deploy-facebook \
  -H "Content-Type: application/json" \
  -d '{
    "videoPath": "[영상 경로]",
    "title": "[제목]",
    "description": "[설명]\n\n이 포스팅은 쿠팡 파트너스 활동의 일환으로 일정액의 수수료를 제공받습니다.",
    "published": true
  }'
```

각 플랫폼 업로드가 실패하면 5초 후 1회 재시도하세요.

### 5. Google Sheets 기록
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/sheets-record \
  -H "Content-Type: application/json" \
  -d '{
    "action": "write_deployment",
    "data": {
      "date": "'$(date +%Y-%m-%d)'",
      "productId": "[상품ID]",
      "productName": "[상품명]",
      "categoryId": "[카테고리]",
      "commentKeyword": "[키워드]",
      "inpockLink": "https://inpock.co.kr/[내계정]",
      "youtubeUrl": "[YT URL]",
      "instagramUrl": "[IG URL]",
      "tiktokUrl": "[TT URL]",
      "facebookUrl": "[FB URL]",
      "deployStatus": "[N]/4",
      "scriptScore": [검수점수],
      "commentMonitoring": "ON"
    }
  }'
```

### 6. 배포 결과 보고
```
쇼츠 배포 완료! ([N]/4 플랫폼)

상품: [상품명]
대본 점수: [N]/10
댓글 키워드: "[키워드]"

○ YouTube: [URL]
○ Instagram: [URL]
○ TikTok: [URL 또는 실패 사유]
○ Facebook: [URL]

인포크링크: https://inpock.co.kr/[내계정]

다음 단계: 인포크 매니저에서 이 릴스에 키워드 DM을 설정하세요.
키워드: "[키워드]"
```

---

## 분석 모드

"성과 분석해줘" 또는 22:00 트리거 시 이 모드를 실행하세요.

### 1. 주간 성과 수집
```bash
curl -s -X POST http://localhost:5678/webhook/shopping-shorts/sheets-record \
  -H "Content-Type: application/json" \
  -d '{"action":"read_performance","days":7}'
```

### 2. 분석 + 보고
수집된 데이터를 분석하여 보고하세요:

```
[일간 성과 리포트]

오늘 배포: [N]개 쇼츠
- [상품명]: 조회 [N] / 댓글 [N] / 클릭 [N]

[7일 트렌드]
총 조회수: [N]
총 댓글: [N]
추정 커미션: [N]원

[인사이트]
- 가장 성과 좋은 카테고리: [카테고리]
- 발견된 패턴: [설명]

[내일 추천]
카테고리: [추천]
이유: [설명]
```

데이터가 3일 미만이면: "아직 데이터가 부족합니다. 3일 이상 운영 후 패턴 분석이 가능합니다."
